package com.bignerdranch.android.animationchristmas.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)

val PomonaGreen = Color (0xFF165B33)
val SpringGreen = Color (0xFF146B3A)
val OrangeYellow = Color (0xFFF8B229)
val Cinnabar = Color (0xFFEA4630)
val Firebrick = Color (0xFFBB2528)
val Snow = Color (0xFFFFFAFA)
val White = Color (0xFFFFFFFF)
val BlizzardBlue = Color (0xFFB2DAFA)
val BluePurple = Color (0xFF9acef8)